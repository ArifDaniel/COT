/* 
    Nothing to read here :)
*/

const init = () => {
    /* Multishot Foreshadow. */
    Blocks.foreshadow.shots = 5;

    Blocks.foreshadow.recoilAmount = 25;

    Blocks.foreshadow.reloadTime=20
};

init();
